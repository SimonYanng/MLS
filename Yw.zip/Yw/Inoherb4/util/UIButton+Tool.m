//
//  UIButton+Tool.m
//  Inoherb
//
//  Created by Bruce on 15/4/3.
//  Copyright (c) 2015年 Bruce.ren. All rights reserved.
//

#import "UIButton+Tool.h"

@implementation UIButton (Tool)



@end
