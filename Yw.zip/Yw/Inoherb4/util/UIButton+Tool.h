//
//  UIButton+Tool.h
//  Inoherb
//
//  Created by Bruce on 15/4/3.
//  Copyright (c) 2015年 Bruce.ren. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Tool)



@end
