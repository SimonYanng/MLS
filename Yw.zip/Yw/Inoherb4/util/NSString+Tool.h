//
//  NSString+Tool.h
//  SFA1
//
//  Created by Ren Yong on 14-4-11.
//  Copyright (c) 2014年 Bruce.ren. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Tool)
-(BOOL) isEmpty;
-(BOOL) isEqualToLowerString:(NSString *)aString;
@end
