//
//  Frm_HDlist.h
//  Inoherb
//
//  Created by Bruce on 15/3/31.
//  Copyright (c) 2015年 Bruce.ren. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "C_ViewButtonList.h"
#import "F_Delegate.h"
#import "C_Filter.h"
@interface Frm_HDlist : UIViewController<UITableViewDataSource,UITableViewDelegate>

-(id)init;
@end
