//
//  Frm_Map.m
//  Inoherb
//
//  Created by Bruce on 15/5/29.
//  Copyright (c) 2015年 Bruce.ren. All rights reserved.
//

#import "Frm_Map.h"
#import "C_NavigationBar.h"
#import "C_GradientButton.h"
#import "Constants.h"
#import "DB.h"
#import "F_Font.h"

#import "C_ShowGps.h"

#define MYBUNDLE_NAME @ "mapapi.bundle"
#define MYBUNDLE_PATH [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: MYBUNDLE_NAME]
#define MYBUNDLE [NSBundle bundleWithPath: MYBUNDLE_PATH]

@interface RouteAnnotation : BMKPointAnnotation
{
    int _type; ///<0:起点 1：终点 2：公交 3：地铁 4:驾乘 5:途经点
    int _degree;
}

@property (nonatomic) int type;
@property (nonatomic) int degree;
@end

@implementation RouteAnnotation

@synthesize type = _type;
@synthesize degree = _degree;
@end

@interface Frm_Map ()
{
    UIView* _backView;
    C_NavigationBar* bar;
    NSMutableDictionary* _selectClient;
    NSMutableArray* arr_client;
    UILabel* _name;
    UILabel* _address;
     BMKRouteSearch* _routesearch;
    BMKUserLocation* _userloc;
}

@end

@implementation Frm_Map


@synthesize locService=_locService;
@synthesize mapView=_mapView;

-(id)init
{
    self = [super init];
    if (self) {
        
        //        NSLog(@"日期%@---------今天%@",[login_date() substringToIndex:7],[today() substringToIndex:7]);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addNavigationBar];
    //    [self initLoc];
    
}

-(void)addNavigationBar
{
    bar=[[C_NavigationBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, SYSTITLEHEIGHT) title:@"周边拜访"];
    [self.view addSubview:bar];
    C_GradientButton* btn_Back=[[C_GradientButton alloc] initWithFrame:CGRectMake(0, 0, 60, 30) buttonId:-1];
    
    [btn_Back setTitle:@"" forState:UIControlStateNormal];
    [btn_Back useImgStyle];
    [btn_Back addTarget:self action:@selector(backClicked:) forControlEvents:UIControlEventTouchUpInside];
    [bar addLeftButton:btn_Back];
    
    //    C_GradientButton* btn_Save=[[C_GradientButton alloc] initWithFrame:CGRectMake(0, 0, 60, 30)];
    //    [btn_Save setTitle:@"提交" forState:UIControlStateNormal];
    //    [btn_Save useAddHocStyle];
    //    [btn_Save addTarget:self action:@selector(saveClicked:) forControlEvents:UIControlEventTouchUpInside];
    //    [bar addRightButton:btn_Save];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)backClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)initLoc
{
    _mapView=[[BMKMapView alloc] initWithFrame:CGRectMake(0, SYSTITLEHEIGHT, self.view.frame.size.width, self.view.frame.size.height-SYSTITLEHEIGHT)];
    _mapView.zoomLevel=_mapView.maxZoomLevel;
    //    _mapView.zoomEnabled=YES;
    //    _mapView.zoomEnabledWithTap=YES;
    [self.view addSubview:_mapView];
    
    
    _locService = [[BMKLocationService alloc]init];
    //    [_locService startUserLocationService];
    //    _mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
    //    _locService.delegate = self;
    //    _mapView.showsUserLocation = YES;//显示定位图层
    
}

-(void)viewWillAppear:(BOOL)animated {
    [self initLoc];
    [_mapView viewWillAppear];
    _mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
    _locService.delegate = self;
    [self startLocation];
}

-(void)viewWillDisappear:(BOOL)animated {
    [_mapView viewWillDisappear];
    _mapView.delegate = nil; // 不用时，置nil
    _locService.delegate = nil;
}

-(void)startLocation
{
    NSLog(@"进入普通定位态");
    [_locService startUserLocationService];
    //    _mapView.showsUserLocation = NO;//先关闭显示的定位图层
    //    _mapView.userTrackingMode = BMKUserTrackingModeNone;//设置定位的状态
    _mapView.showsUserLocation = YES;//显示定位图层
    
}

//停止定位
-(IBAction)stopLocation:(id)sender
{
    [_locService stopUserLocationService];
    _mapView.showsUserLocation = NO;
    
}

/**
 *在地图View将要启动定位时，会调用此函数
 *@param mapView 地图View
 */
- (void)willStartLocatingUser
{
    NSLog(@"start locate");
}


/**
 *用户位置更新后，会调用此函数
 *@param userLocation 新的用户位置
 */
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    [_locService stopUserLocationService];
    _userloc=userLocation;
    [self initAnnotation:userLocation];
}

-(void)initAnnotation:(BMKUserLocation *)userLocation
{
    NSMutableString* sql=[NSMutableString stringWithFormat:@"SELECT * from t_outlet_main"];
    arr_client=[[DB instance] fieldListBy:sql];
    CLLocationDistance dis;
    //设定经纬度
    int index=0;
    for (NSMutableDictionary*client in arr_client) {
        NSLog(@"%@-----%f,%f",[client getString:@"fullname"],[client getDouble:@"lon"],[client getDouble:@"lat"]);
        CLLocationCoordinate2D coordinate;
        coordinate.longitude=[client getDouble:@"lon"];
        coordinate.latitude=[client getDouble:@"lat"];
        
        CLLocation* orig=[[CLLocation alloc] initWithLatitude:[client getDouble:@"lat"]  longitude:[client getDouble:@"lon"]];
        
        //        NSLog(@"%d-------------------",[userLocation.location distanceFromLocation:newLoc]);
        
        if( [userLocation.location distanceFromLocation:orig]<=2000)
        {
            BMKPointAnnotation* annotation = [[BMKPointAnnotation alloc]init];
            
            annotation.coordinate = coordinate;
            //            annotation.title=index;
            annotation.title = [client getString:@"fullname"];
            
            [_mapView addAnnotation:annotation];
            
        }
    }
    [_mapView updateLocationData:userLocation];
    [_mapView setCenterCoordinate:userLocation.location.coordinate animated:YES];
    //    arr_client
    index++;
}

-(void)mapView:(BMKMapView *)mapView didSelectAnnotationView:(BMKAnnotationView *)view
{
    for (NSMutableDictionary* client in arr_client) {
        if([[client  getString:@"fullname"] isEqualToString:[view.annotation title]])
        {
            _selectClient=client;
            break;
        }
    }
    [self initBackView];
    NSLog(@"----按时大大");
}


-(void)initBackView
{
    
    if(!_backView)
    {
        _backView=[[UIView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-100, self.view.frame.size.width, 100)];
        [_backView setBackgroundColor:[UIColor whiteColor]];
        [self.view addSubview:_backView];
        
        _name=[[UILabel alloc] initWithFrame:CGRectMake(5, 5, _backView.frame.size.width-10, 20)];
        [_name setText:[_selectClient getString:@"fullname"]];
        [_backView addSubview:_name];
        
        _address=[[UILabel alloc] initWithFrame:CGRectMake(5, 30, _backView.frame.size.width-10, 20)];
        [_address setText:[_selectClient getString:@"address"]];
        [_address setFont: [UIFont fontWithName:@"Helvetica" size:13]];
        [_address setTextColor:[UIColor lightGrayColor]];
        [_backView addSubview:_address];
        
        C_GradientButton* btn_Hoc=[[C_GradientButton alloc] initWithFrame:CGRectMake(10, _backView.frame.size.height-40, _backView.frame.size.width/2-15, 30)];
        [btn_Hoc setTitle:@"路线" forState:UIControlStateNormal];
        [btn_Hoc useGPSStyle];
        [btn_Hoc addTarget:self action:@selector(routSearch:) forControlEvents:UIControlEventTouchUpInside];
        [_backView addSubview:btn_Hoc];
        
        btn_Hoc=[[C_GradientButton alloc] initWithFrame:CGRectMake(_backView.frame.size.width/2+5, _backView.frame.size.height-40, _backView.frame.size.width/2-15, 30)];
        [btn_Hoc setTitle:@"导航" forState:UIControlStateNormal];
        [btn_Hoc useGPSStyle];
        [btn_Hoc addTarget:self action:@selector(webNavi:) forControlEvents:UIControlEventTouchUpInside];
        [_backView addSubview:btn_Hoc];
    }
    else
    {
        [_name setText:[_selectClient getString:@"fullname"]];
        [_address setText:[_selectClient getString:@"address"]];
        
        _backView.hidden=NO;
    }
}

//-(void)show
//{
//    C_ShowGps* showGps=[[C_ShowGps alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-100, self.view.frame.size.width, 100) data:[arr_client dictAt:5]];
//    [showGps showInView:self.view];
//}

/**
 *在地图View停止定位后，会调用此函数
 *@param mapView 地图View
 */
- (void)didStopLocatingUser
{
    NSLog(@"stop locate");
}

/**
 *定位失败后，会调用此函数
 *@param mapView 地图View
 *@param error 错误号，参考CLError.h中定义的错误号
 */
- (void)didFailToLocateUserWithError:(NSError *)error
{
    NSLog(@"location error");
}

-(void)routSearch:(id)sender
{
    _routesearch = [[BMKRouteSearch alloc]init];
    _routesearch.delegate = self;
    
    BMKPlanNode* start = [[BMKPlanNode alloc]init];
    start.name =@"当前位置";
//    start.cityName = @"上海市";
    CLLocationCoordinate2D coor1;
    coor1.latitude = _userloc.location.coordinate.latitude;
    coor1.longitude = _userloc.location.coordinate.longitude;
    start.pt = coor1;
    //指定起点名称
    
    BMKPlanNode* end = [[BMKPlanNode alloc]init];
    end.name = [_selectClient getString:@"fullname"];
    CLLocationCoordinate2D coor2;
    coor2.latitude = [_selectClient getDouble:@"lat"];
    coor2.longitude =  [_selectClient getDouble:@"lon"];
    end.pt = coor2;
    
    
    BMKWalkingRoutePlanOption *walkingRouteSearchOption = [[BMKWalkingRoutePlanOption alloc]init];
    walkingRouteSearchOption.from = start;
    walkingRouteSearchOption.to = end;
    BOOL flag = [_routesearch walkingSearch:walkingRouteSearchOption];
    if(flag)
    {
        NSLog(@"walk检索发送成功");
    }
    else
    {
        NSLog(@"walk检索发送失败");
    }
}

- (void)webNavi:(id)sender
{
    //初始化调启导航时的参数管理类
    BMKNaviPara* para = [[BMKNaviPara alloc]init];
    //指定导航类型
    para.naviType = BMK_NAVI_TYPE_WEB;
    
    //初始化起点节点
    BMKPlanNode* start = [[BMKPlanNode alloc]init];
    //指定起点经纬度
    CLLocationCoordinate2D coor1;
    coor1.latitude = _userloc.location.coordinate.latitude;
    coor1.longitude = _userloc.location.coordinate.longitude;
    start.pt = coor1;
    //指定起点名称
    start.name = @"当前位置";
    //指定起点
    para.startPoint = start;
    
    //初始化终点节点
    BMKPlanNode* end = [[BMKPlanNode alloc]init];
    CLLocationCoordinate2D coor2;
    coor2.latitude = [_selectClient getDouble:@"lat"];
    coor2.longitude =  [_selectClient getDouble:@"lon"];
    end.pt = coor2;
    para.endPoint = end;
    //指定终点名称
    end.name =  [_selectClient getString:@"fullname"];
    //指定调启导航的app名称
    para.appName = [NSString stringWithFormat:@"%@", @"jahwa"];
    //调启web导航
    [BMKNavigation openBaiduMapNavigation:para];
}

- (void)onGetWalkingRouteResult:(BMKRouteSearch*)searcher result:(BMKWalkingRouteResult*)result errorCode:(BMKSearchErrorCode)error
{
//    BMKRouteSearch.
    NSArray* array = [NSArray arrayWithArray:_mapView.annotations];
    [_mapView removeAnnotations:array];
    array = [NSArray arrayWithArray:_mapView.overlays];
    [_mapView removeOverlays:array];
    if (error == BMK_SEARCH_NO_ERROR) {
        BMKWalkingRouteLine* plan = (BMKWalkingRouteLine*)[result.routes objectAtIndex:0];
        int size = [plan.steps count];
        int planPointCounts = 0;
        for (int i = 0; i < size; i++) {
            BMKWalkingStep* transitStep = [plan.steps objectAtIndex:i];
            if(i==0){
                RouteAnnotation* item = [[RouteAnnotation alloc]init];
                item.coordinate = plan.starting.location;
                item.title = @"起点";
                item.type = 0;
                [_mapView addAnnotation:item]; // 添加起点标注
                
            }else if(i==size-1){
                RouteAnnotation* item = [[RouteAnnotation alloc]init];
                item.coordinate = plan.terminal.location;
                item.title = @"终点";
                item.type = 1;
                [_mapView addAnnotation:item]; // 添加起点标注
            }
            //添加annotation节点
            RouteAnnotation* item = [[RouteAnnotation alloc]init];
            item.coordinate = transitStep.entrace.location;
            item.title = transitStep.entraceInstruction;
            item.degree = transitStep.direction * 30;
            item.type = 4;
            [_mapView addAnnotation:item];
            
            //轨迹点总数累计
            planPointCounts += transitStep.pointsCount;
        }
        
        //轨迹点
        BMKMapPoint * temppoints =new BMKMapPoint[planPointCounts];
        int i = 0;
        for (int j = 0; j < size; j++) {
            BMKWalkingStep* transitStep = [plan.steps objectAtIndex:j];
            int k=0;
            for(k=0;k<transitStep.pointsCount;k++) {
                temppoints[i].x = transitStep.points[k].x;
                temppoints[i].y = transitStep.points[k].y;
                i++;
            }
            
        }
        // 通过points构建BMKPolyline
        BMKPolyline* polyLine = [BMKPolyline polylineWithPoints:temppoints count:planPointCounts];
        [_mapView addOverlay:polyLine]; // 添加路线overlay
        delete []temppoints;
        
    
    }

}

@end
