//
//  Frm_MsgList.h
//  Inoherb4
//
//  Created by Ren Yong on 14-6-10.
//  Copyright (c) 2014年 Bruce.ren. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface Frm_MsgList : UIViewController<UITableViewDataSource,UITableViewDelegate>


@end
